package util;

public interface IMenu {
    void menu();
}
